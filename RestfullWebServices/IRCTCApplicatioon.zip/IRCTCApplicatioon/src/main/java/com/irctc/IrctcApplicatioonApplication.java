package com.irctc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class IrctcApplicatioonApplication {

	public static void main(String[] args) {
		SpringApplication.run(IrctcApplicatioonApplication.class, args);
		System.out.println("Application has been sucessfully started....");
	}

}
